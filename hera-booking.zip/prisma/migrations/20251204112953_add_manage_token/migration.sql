-- AlterTable
ALTER TABLE "Appointment" ADD COLUMN "manageToken" TEXT;
